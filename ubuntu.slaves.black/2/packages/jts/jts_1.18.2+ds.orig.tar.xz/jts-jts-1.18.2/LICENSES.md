# JTS Topology Suite Licensing

May 30th, 2017

## Project Licenses

The Eclipse Foundation makes available all content in this project ("Content"). Unless otherwise indicated below, the Content is provided to you under the terms and conditions of either the [Eclipse Public License 2.0](https://www.eclipse.org/legal/epl-v20.html) ("EPL") or the [Eclipse Distribution License 1.0](http://www.eclipse.org/org/documents/edl-v10.php) (a BSD Style License).  For purposes of the EPL, "Program" will mean the Content.

If you did not receive this Content directly from the Eclipse Foundation, the Content is being redistributed by another party ("Redistributor") and different terms and conditions may apply to your use of any object code in the Content. Check the Redistributor's license that was provided with the Content. If no such license exists, contact the Redistributor. Unless otherwise indicated below, the terms and conditions of the EPL still apply to any source code in the Content and such source code may be obtained at http://www.eclipse.org.

## Third Party Content

The Content includes items that have been sourced from third parties as set out below. If you did not receive this Content directly from the Eclipse Foundation, the following is provided for informational purposes only, and you should look to the Redistributor's license for terms and conditions of use.

### GeoTools 

JTS includes some code from the GeoTools project.  This code has been licensed to the JTS project under the OSGeo BSD License [2] by the GeoTools PSC [3,4].

[2] https://www.osgeo.org/sites/osgeo.org/files/Page/osgeo-bsd-license.txt
[3] https://github.com/geotools/geotools/wiki/JTS-ORA-Contribution
[4] https://github.com/geotools/geotools/wiki/JTS-Shapefile-Contribution
