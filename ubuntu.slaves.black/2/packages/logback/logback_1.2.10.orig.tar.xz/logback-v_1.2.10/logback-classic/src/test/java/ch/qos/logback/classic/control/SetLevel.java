/**
 * Logback: the reliable, generic, fast and flexible logging framework.
 * Copyright (C) 1999-2015, QOS.ch. All rights reserved.
 *
 * This program and the accompanying materials are dual-licensed under
 * either the terms of the Eclipse Public License v1.0 as published by
 * the Eclipse Foundation
 *
 *   or (per the licensee's choosing)
 *
 * under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation.
 */
package ch.qos.logback.classic.control;

import ch.qos.logback.classic.Level;

public class SetLevel extends ScenarioAction {
    final String loggerName;
    final Level level;

    public SetLevel(Level level, String loggerName) {
        this.level = level;
        this.loggerName = loggerName;
    }

    public Level getLevel() {
        return level;
    }

    public String getLoggerName() {
        return loggerName;
    }

    public String toString() {
        return "SetLevel(" + level + ", " + loggerName + ")";
    }
}
