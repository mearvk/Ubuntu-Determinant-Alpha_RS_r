/**
 * Copyright (c) 2010 itemis AG (http://www.itemis.eu) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v20.html
 */
package org.eclipse.emf.codegen.ecore.xtext.ui;


import org.eclipse.xtext.ui.guice.AbstractGuiceAwareExecutableExtensionFactory;
import org.osgi.framework.Bundle;

import com.google.inject.Injector;


public class ExecutableExtensionFactory extends AbstractGuiceAwareExecutableExtensionFactory
{

  @Override
  protected Bundle getBundle()
  {
    return Activator.getDefault().getBundle();
  }

  @Override
  protected Injector getInjector()
  {
    return Activator.getDefault().getInjector();
  }

}
