# Contributing to r.js

[See the requirejs.org contributing page](http://requirejs.org/docs/contributing.html).

If you have a question about a specific setup or using particular libraries or file layouts with requirejs/r.js, then it is best to ask that on [Stack Overflow using the requirejs tag](https://stackoverflow.com/questions/tagged/requirejs). New issues here are best used for bug reports that have test cases or examples.
