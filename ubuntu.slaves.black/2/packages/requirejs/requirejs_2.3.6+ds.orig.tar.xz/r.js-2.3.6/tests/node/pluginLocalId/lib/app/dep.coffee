define (require) ->
  'dep'