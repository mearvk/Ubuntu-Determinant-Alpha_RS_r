define({
    name: 'foo'
});
