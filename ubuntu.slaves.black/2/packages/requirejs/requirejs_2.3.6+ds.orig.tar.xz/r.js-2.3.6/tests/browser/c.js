define({
    name: 'c'
});