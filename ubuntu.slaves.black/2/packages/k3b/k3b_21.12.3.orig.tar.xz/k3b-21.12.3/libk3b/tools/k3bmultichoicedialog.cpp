/*
    SPDX-FileCopyrightText: 1998-2008 Sebastian Trueg <trueg@k3b.org>

    SPDX-License-Identifier: GPL-2.0-or-later
*/

#include "k3bmultichoicedialog.h"
#include "k3bstdguiitems.h"

#include <KIconLoader>

#include <QCloseEvent>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLayout>
#include <QMessageBox>
#include <QPushButton>


class K3b::MultiChoiceDialog::Private
{
public:
    Private()
        : buttonLayout(0) {
    }

    QList<QPushButton*> buttons;
    QHBoxLayout* buttonLayout;

    bool buttonClicked;
};


// from kmessagebox.cpp
static QIcon themedMessageBoxIcon(QMessageBox::Icon icon)
{
    QString icon_name;

    switch (icon) {
    case QMessageBox::NoIcon:
        return QIcon();
        break;
    case QMessageBox::Information:
        icon_name = "dialog-information";
        break;
    case QMessageBox::Warning:
        icon_name = "dialog-warning";
        break;
    case QMessageBox::Critical:
        icon_name = "dialog-error";
        break;
    default:
        break;
    }

    QIcon ret = KIconLoader::global()->loadIcon(icon_name, KIconLoader::NoGroup, KIconLoader::SizeLarge, KIconLoader::DefaultState, QStringList(), 0, true);

    if (ret.isNull()) {
        return QMessageBox::standardIcon(icon);
    } else {
        return ret;
    }
}


K3b::MultiChoiceDialog::MultiChoiceDialog( const QString& caption,
                                            const QString& text,
                                            QMessageBox::Icon icon,
                                            QWidget* parent )
    : QDialog( parent )
{
    d = new Private();

    setWindowTitle( caption );

    QGridLayout* mainGrid = new QGridLayout( this );

    QHBoxLayout* contents = new QHBoxLayout;
    contents->setSpacing( contents->spacing()*2 );
    contents->setContentsMargins( 0, 0, 0, 0 );

    QLabel* pixLabel = new QLabel( this );
    int size = IconSize(KIconLoader::Dialog);
    pixLabel->setPixmap( themedMessageBoxIcon( icon ).pixmap( size, size ) );
    pixLabel->setScaledContents( false );
    QLabel* label = new QLabel( text, this );
    label->setWordWrap( true );
    contents->addWidget( pixLabel, 0 );
    contents->addWidget( label, 1 );

    d->buttonLayout = new QHBoxLayout;
    d->buttonLayout->setContentsMargins( 0, 0, 0, 0 );

    mainGrid->addLayout( contents, 0, 0, 1, 3 );
    mainGrid->addWidget( K3b::StdGuiItems::horizontalLine( this ), 1, 0, 1, 3 );
    mainGrid->addLayout( d->buttonLayout, 2, 1 );

    mainGrid->setColumnStretch( 0, 1 );
    mainGrid->setColumnStretch( 2, 1 );
    mainGrid->setRowStretch( 0, 1 );
}


K3b::MultiChoiceDialog::~MultiChoiceDialog()
{
    delete d;
}


int K3b::MultiChoiceDialog::addButton( const KGuiItem& b )
{
    QPushButton* button = new QPushButton( this );
    KGuiItem::assign( button, b );
    d->buttonLayout->addWidget( button );
    d->buttons.append(button);
    const auto buttonId = d->buttons.count();
    connect( button, &QAbstractButton::clicked, this, [this, buttonId]() { done(buttonId); } );
    return buttonId;
}


void K3b::MultiChoiceDialog::slotButtonClicked( int code )
{
    d->buttonClicked = true;
    done( code );
}


int K3b::MultiChoiceDialog::exec()
{
    d->buttonClicked = false;
    return QDialog::exec();
}


void K3b::MultiChoiceDialog::closeEvent( QCloseEvent* e )
{
    // make sure the dialog can only be closed by the buttons
    // otherwise we may get an undefined return value in exec

    if( d->buttonClicked )
        QDialog::closeEvent( e );
    else
        e->ignore();
}


int K3b::MultiChoiceDialog::choose( const QString& caption,
                                  const QString& text,
                                  QMessageBox::Icon icon,
                                  QWidget* parent,
                                  int buttonCount,
                                  const KGuiItem& b1,
                                  const KGuiItem& b2,
                                  const KGuiItem& b3,
                                  const KGuiItem& b4,
                                  const KGuiItem& b5,
                                  const KGuiItem& b6 )
{
    K3b::MultiChoiceDialog dlg( caption, text, icon, parent );
    dlg.addButton( b1 );
    if( buttonCount > 1 )
        dlg.addButton( b2 );
    if( buttonCount > 2 )
        dlg.addButton( b3 );
    if( buttonCount > 3 )
        dlg.addButton( b4 );
    if( buttonCount > 4 )
        dlg.addButton( b5 );
    if( buttonCount > 5 )
        dlg.addButton( b6 );

    return dlg.exec();
}



