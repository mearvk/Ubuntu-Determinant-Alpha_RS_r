/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* $Id: GraphicsSetCharacterSet.java 1297404 2012-03-06 10:17:54Z vhennebert $ */

package org.apache.fop.afp.goca;

import java.io.IOException;
import java.io.OutputStream;

import org.apache.fop.afp.util.BinaryUtils;

/**
 * Sets the current character set (font) to be used for following graphics strings
 */
public class GraphicsSetCharacterSet extends AbstractGraphicsDrawingOrder {

    /** font character set reference */
    private final int fontReference;

    /**
     * @param fontReference character set font reference
     */
    public GraphicsSetCharacterSet(int fontReference) {
        this.fontReference = fontReference;
    }

    /** {@inheritDoc} */
    public void writeToStream(OutputStream os) throws IOException {
        byte[] data = new byte[] {
            getOrderCode(), // GSCS order code
            BinaryUtils.convert(fontReference)[0]
        };
        os.write(data);
    }

    /** {@inheritDoc} */
    public int getDataLength() {
        return 2;
    }

    /** {@inheritDoc} */
    public String toString() {
        return "GraphicsSetCharacterSet(" + fontReference + ")";
    }

    /** {@inheritDoc} */
    byte getOrderCode() {
        return 0x38;
    }

}
