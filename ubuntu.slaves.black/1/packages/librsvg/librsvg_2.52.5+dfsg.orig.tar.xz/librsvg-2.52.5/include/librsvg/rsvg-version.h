#if !defined (__RSVG_RSVG_H_INSIDE__) && !defined (RSVG_COMPILATION)
#warning "Including <librsvg/rsvg-version.h> directly is deprecated."
#endif

#ifndef RSVG_VERSION_H
#define RSVG_VERSION_H

#define LIBRSVG_MAJOR_VERSION (2)
#define LIBRSVG_MINOR_VERSION (52)
#define LIBRSVG_MICRO_VERSION (5)
#define LIBRSVG_VERSION "2.52.5"

#endif
