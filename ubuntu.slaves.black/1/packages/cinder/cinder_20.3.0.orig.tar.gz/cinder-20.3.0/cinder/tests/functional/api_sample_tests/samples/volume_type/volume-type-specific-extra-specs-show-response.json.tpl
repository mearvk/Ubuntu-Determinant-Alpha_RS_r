{
    "capabilities": "gpu"
}
