# Copyright (C) 2018 NTT DATA
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

"""Schema for V3 volume type encryption API."""

import copy

from cinder.api.validation import parameter_types

create = {
    'type': 'object',
    'properties': {
        'encryption': {
            'type': 'object',
            'properties': {
                'key_size': parameter_types.key_size,
                'provider': {'type': 'string', 'minLength': 0,
                             'maxLength': 255},
                'control_location': {'enum': ['front-end', 'back-end']},
                'cipher': {'type': ['string', 'null'],
                           'minLength': 0, 'maxLength': 255},
            },
            'required': ['provider', 'control_location'],
            'additionalProperties': True,
        },
    },
    'required': ['encryption'],
    'additionalProperties': False,
}


update = copy.deepcopy(create)
update['properties']['encryption']['required'] = []
