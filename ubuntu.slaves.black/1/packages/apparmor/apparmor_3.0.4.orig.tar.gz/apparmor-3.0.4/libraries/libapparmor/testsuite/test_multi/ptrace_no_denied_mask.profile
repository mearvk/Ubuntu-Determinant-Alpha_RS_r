/usr/bin/pidgin {
}
