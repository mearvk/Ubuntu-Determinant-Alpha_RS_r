CREATE DATABASE numismatics;  
