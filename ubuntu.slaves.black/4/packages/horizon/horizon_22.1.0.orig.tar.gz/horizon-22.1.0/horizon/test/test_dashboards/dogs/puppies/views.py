#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from horizon import tabs
from horizon.test.test_dashboards.dogs.puppies import tabs as dogs_tabs
from horizon import views


class IndexView(views.APIView):
    # A very simple class-based view...
    template_name = 'dogs/puppies/index.html'

    def get_data(self, request, context, *args, **kwargs):
        # Add data to the context here...
        return context


class TwoTabsView(tabs.TabbedTableView):
    tab_group_class = dogs_tabs.PuppiesTabs
    template_name = 'dogs/puppies/two_tabs.html'
