/* -*- mode: C; c-file-style: "gnu"; indent-tabs-mode: nil; -*- */
/* gvfs - extensions for gio
 *
 * Copyright (C) 2006-2009 Red Hat, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Author: David Zeuthen <davidz@redhat.com>
 */

#ifndef __G_GDU_VOLUME_MONITOR_H__
#define __G_GDU_VOLUME_MONITOR_H__

#include <glib-object.h>
#include <gio/gio.h>
#include <gio/gunixmounts.h>

/* for dev_t */
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <gdu/gdu.h>

G_BEGIN_DECLS

#define G_TYPE_GDU_VOLUME_MONITOR        (g_gdu_volume_monitor_get_type ())
#define G_GDU_VOLUME_MONITOR(o)          (G_TYPE_CHECK_INSTANCE_CAST ((o), G_TYPE_GDU_VOLUME_MONITOR, GGduVolumeMonitor))
#define G_GDU_VOLUME_MONITOR_CLASS(k)    (G_TYPE_CHECK_CLASS_CAST((k), G_TYPE_GDU_VOLUME_MONITOR, GGduVolumeMonitorClass))
#define G_IS_GDU_VOLUME_MONITOR(o)       (G_TYPE_CHECK_INSTANCE_TYPE ((o), G_TYPE_GDU_VOLUME_MONITOR))
#define G_IS_GDU_VOLUME_MONITOR_CLASS(k) (G_TYPE_CHECK_CLASS_TYPE ((k), G_TYPE_GDU_VOLUME_MONITOR))

typedef struct _GGduVolumeMonitor GGduVolumeMonitor;
typedef struct _GGduVolumeMonitorClass GGduVolumeMonitorClass;

/* Forward definitions */
typedef struct _GGduDrive GGduDrive;
typedef struct _GGduVolume GGduVolume;
typedef struct _GGduMount GGduMount;

struct _GGduVolumeMonitorClass {
  GNativeVolumeMonitorClass parent_class;

};

GType g_gdu_volume_monitor_get_type (void) G_GNUC_CONST;

GVolumeMonitor *g_gdu_volume_monitor_new                          (void);

gboolean _is_pc_floppy_drive (GduDevice *device);

G_END_DECLS

#endif /* __G_GDU_VOLUME_MONITOR_H__ */
